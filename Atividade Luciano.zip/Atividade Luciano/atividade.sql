-- 1) Identifique departamentos com mais de 15 funcionários.
SELECT * FROM departamento 
WHERE qtdfuncionariosdepto > 15;

-- 2) Selecione os nomes dos funcionários cujo salário é maior ou igual a R$ 4.000.
SELECT nome_funcionario  FROM funcionario 
WHERE salario >= 4000;

-- 3) Calcular a média salarial dos funcionários.
SELECT sigla_depto,avg(salario) FROM funcionario 
group by sigla_depto;

-- 4) Calcular a média (estude como usar a função AVG) salarial dos funcionários com duas casas decimais de precisão após a vírgula, (estude como usar a função ROUND).
SELECT sigla_depto, round(avg(salario),1) FROM funcionario 
group by sigla_depto;

-- 5) Encontre funcionários cujo nome contém "Gomes".
SELECT nome_funcionario FROM funcionario 
WHERE nome_funcionario =   'Gomes';

-- 6) Calcule o salário anual de todos os funcionários.
SELECT nome_funcionario, salario*12
FROM funcionario;

-- 7) Identifique o funcionário com o salário mais alto (estude como usar a função MAX).
SELECT * FROM funcionario;
SELECT nome_funcionario FROM funcionario
WHERE salario IN  (SELECT MAX(salario)
FROM funcionario);
 
-- 8) Identifique os 2 salários mais altos, (estude como usar a função LIMIT).
SELECT * FROM funcionario ORDER BY salario DESC LIMIT 2;

-- 9) Identifique o funcionário mais velho de cada cargo (com mais tempo de serviço).
SELECT nome_funcionario, cargo, data_admissao 
FROM funcionario
WHERE (sigla_depto, data_admissao) IN (
	SELECT sigla_depto, MIN(data_admissao)
    FROM funcionario
    GROUP BY sigla_depto
); 

-- 10) Encontre departamentos com pelo menos um funcionario com salário superior a R$ 5.000.
SELECT DISTINCT cargo, sigla_depto, salario  FROM funcionario
WHERE salario >= 5000;

-- 11) Encontre os departamentos onde pelo menos um funcionário tem um salário superior ao salário médio de todos os funcionários.
SELECT sigla_depto, cargo, salario	FROM funcionario WHERE salario > (SELECT avg(salario) FROM funcionario);

-- 12) Encontre departamentos com pelo menos um funcionário cujo nome contenha "Costa".
SELECT sigla_depto, nome_funcionario FROM funcionario
WHERE nome_funcionario like "%Costa";

-- 13) Encontre departamentos onde pelo menos um funcionário tem um salário superior ao salário médio de seu próprio departamento.
SELECT sigla_depto FROM funcionario
WHERE EXISTS (
SELECT * FROM funcionario
WHERE salario > (SELECT AVG (salario) FROM funcionario)
);